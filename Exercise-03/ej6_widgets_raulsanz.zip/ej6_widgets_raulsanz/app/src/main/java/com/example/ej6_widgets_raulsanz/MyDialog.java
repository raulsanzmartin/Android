package com.example.ej6_widgets_raulsanz;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;

import androidx.fragment.app.DialogFragment;

public class MyDialog extends DialogFragment {
    respuestaMyDialog respuesta;
    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
// Usamos la clase Builder para construir el diálogo
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
//Escribimos el título
        builder.setTitle("Pregunta muy importante:");
//Escribimos la pregunta
        builder.setMessage("¿Es un buen día?");
//añadimos el botón de Si y su acción asociada
        builder.setPositiveButton("¡SI!", new DialogInterface.OnClickListener()
        {
            public void onClick(DialogInterface dialog, int id) {
                respuesta.onRespuesta("Es un buen día!");
            }
        });
//añadimos el botón de No y su acción asociada
        builder.setNegativeButton("¡NO!", new DialogInterface.OnClickListener()
        {
            public void onClick(DialogInterface dialog, int id) {
                respuesta.onRespuesta("Es un mal día!");
            }
        });
        return builder.create();
    }
    public interface respuestaMyDialog {
        public void onRespuesta(String s);
    }
    // Se invoca cuando el fragmento se añade a la actividad
    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        respuesta=(respuestaMyDialog)context;
    }
}


