package com.example.ejercicio_persistencia_07;

import androidx.appcompat.app.AppCompatActivity;

import android.content.res.Resources;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class MainActivity extends AppCompatActivity {

    Button btnLeer,btnReset;
    TextView txtLectura;
    BufferedReader br;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnLeer=findViewById(R.id.btnLeer);
        btnReset=findViewById(R.id.btnReset);
        txtLectura=findViewById(R.id.txtLectura);
        txtLectura.setMovementMethod(new ScrollingMovementMethod());

        Resources r=getResources();

        br=new BufferedReader(new InputStreamReader(r.openRawResource(R.raw.prueba)));

        btnReset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                txtLectura.setText("");
                br=new BufferedReader(new InputStreamReader(r.openRawResource(R.raw.prueba)));
            }
        });

        btnLeer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String x;
                try {
                    while ((x=br.readLine())!=null) {
                        txtLectura.append(x);
                        txtLectura.append("\n");
                    }
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
        });
    }
}