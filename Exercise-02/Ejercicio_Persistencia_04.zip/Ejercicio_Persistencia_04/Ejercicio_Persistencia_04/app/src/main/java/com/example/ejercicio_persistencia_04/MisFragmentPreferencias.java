package com.example.ejercicio_persistencia_04;

import android.preference.PreferenceActivity;

import java.util.List;

public class MisFragmentPreferencias extends PreferenceActivity {
    @Override
    protected boolean isValidFragment(String fragmentName) {
        if (DatosPersonales.class.getName().equals(fragmentName)){
            return true;
        } else if (HeroesFav.class.getName().equals(fragmentName)) {
            return true;
        } else if (TusAficiones.class.getName().equals(fragmentName)) {
            return true;
        }
        return false;
    }

    @Override
    public void onBuildHeaders(List<Header> target) {
        super.onBuildHeaders(target);
        loadHeadersFromResource(R.xml.preferences_header,target);
    }
}
