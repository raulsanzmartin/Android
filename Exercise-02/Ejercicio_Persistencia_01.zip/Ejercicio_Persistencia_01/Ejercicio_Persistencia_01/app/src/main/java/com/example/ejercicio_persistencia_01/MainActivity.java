package com.example.ejercicio_persistencia_01;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private SharedPreferences misPref;
    private EditText editNombre,editApellido,editEdad;
    private Button btnCargar;
    private TextView txtNombre,txtApellido,txtEdad;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editNombre=findViewById(R.id.editNombre);
        editApellido=findViewById(R.id.editApellido);
        editEdad=findViewById(R.id.editEdad);
        txtNombre=findViewById(R.id.txtConseguirNombre);
        txtApellido=findViewById(R.id.txtConseguirApellido);
        txtEdad=findViewById(R.id.txtConseguirEdad);
        btnCargar=findViewById(R.id.btnCargar);

        misPref=getSharedPreferences("prac_1",MODE_PRIVATE);

        btnCargar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                txtNombre.setText(misPref.getString("nombre","Sin datos guardados"));
                txtApellido.setText(misPref.getString("apellido","Sin datos guardados"));
                txtEdad.setText(String.valueOf(misPref.getInt("edad",-1)));
            }
        });
    }

    @Override
    protected void onStop() {
        SharedPreferences.Editor editor=misPref.edit();
        editor.putString("nombre",editNombre.getText().toString().trim());
        editor.putString("apellido",editApellido.getText().toString().trim());
        editor.putInt("edad",Integer.parseInt(editEdad.getText().toString().trim()));
        editor.apply();
        super.onStop();
    }
}