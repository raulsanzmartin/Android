package com.example.ejercicio_persistencia_06;

import androidx.appcompat.app.AppCompatActivity;

import android.content.res.Resources;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class MainActivity extends AppCompatActivity {

    Button btnPulsar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Resources r=getResources();
        BufferedReader br=new BufferedReader(new InputStreamReader(r.openRawResource(R.raw.prueba)));

        btnPulsar=findViewById(R.id.btnPulsar);

        btnPulsar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String x;
                try {
                    if ((x=br.readLine())!=null) {
                        Toast.makeText(getApplicationContext(),x,Toast.LENGTH_LONG).show();
                    } else {
                        Toast.makeText(getApplicationContext(),"FIN DEL ARCHIVO",Toast.LENGTH_LONG).show();
                    }
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
        });
    }
}