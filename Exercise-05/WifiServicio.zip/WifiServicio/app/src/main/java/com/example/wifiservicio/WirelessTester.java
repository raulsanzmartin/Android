package com.example.wifiservicio;

import static android.app.Service.START_STICKY;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.IBinder;
import android.util.Log;
import android.view.View;


public class WirelessTester extends Service {
    final String tag = "Demo Servicio";
    public boolean enEjecucion = false;
    public boolean wifi_activo = false;
    private Tester tester; // Se declara una clase que ejecuta un thread

    /**
     * Llamado cuando se crea el servicio.
     */
    @Override
    public void onCreate() {
        Log.i(tag, "Servicio WirelessTester creado!");
        tester = new Tester();
    }

    /**
     * El servicio se arranca mediante una llamada startService()
     * solo lo hace si no estaba previamente arrancado
     */
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (!enEjecucion) {
            enEjecucion = true;
// Se lanza el thread
            tester.start();
            Log.i(tag, "Servicio WirelessTester arrancado!");
        } else {
            Log.i(tag, "El servicio WirelessTester ya estaba arrancado!");
        }
        return START_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
    /**
     * Llamado cuando se destruye el servicio
     */
    @Override
    public void onDestroy() {
        Log.i(tag, "Servicio WirelessTester destruido!");
        if (enEjecucion)
            tester.interrupt();
    }
    public void Arrancar(View v){
        startService(new Intent(getBaseContext(), WirelessTester.class));

    }

    public void Detener(View v){
        stopService(new Intent(getBaseContext(), WirelessTester.class));
    }

    private class Tester extends Thread{
        @Override
        public void run() {
            while(enEjecucion) {
                try {
                    Log.i(tag, "servicio ejecutándose....");
                    if(wifi_activo!=CompruebaConexionWifi()){
                        wifi_activo=!wifi_activo; //Cambio de estado
                        if(wifi_activo)
                            Log.i(tag,"Conexión wifi activada");
                        else
                            Log.i(tag,"Conexión wifi desactivada");
                    }
                    this.sleep(3000);
                } catch (InterruptedException e) {
                    enEjecucion=false;
                    Log.i(tag, "hilo del servicio interrumpido....");
                }
            }
        }

        public boolean CompruebaConexionWifi(){

            ConnectivityManager connectivity = (ConnectivityManager)
                    getApplicationContext().getSystemService(Context.CONNECTIVITY_SERVICE);
            if (connectivity != null) {

                NetworkInfo info = connectivity.getNetworkInfo(ConnectivityManager.TYPE_WIFI);
                if (info != null) {

                    if (info.isConnected()) {
                        return true;//hay conexión
                    }
                }
            }
            return false; //no hay conexión
        }
    }
}