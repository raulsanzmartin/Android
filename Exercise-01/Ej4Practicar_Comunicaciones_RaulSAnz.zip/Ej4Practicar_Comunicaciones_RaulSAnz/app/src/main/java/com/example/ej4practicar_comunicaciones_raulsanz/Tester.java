package com.example.ej4practicar_comunicaciones_raulsanz;

import android.util.Log;

public class Tester extends Thread{


    @Override
    public void run() {
        while() {
            try {
                Log.i(tag, "servicio ejecutándose....");
                if(wifi_activo!=CompruebaConexionWifi()){
                    wifi_activo=!wifi_activo; //Cambio de estado
                    if(wifi_activo)
                        Log.i(tag,"Conexión wifi activada");
                    else
                        Log.i(tag,"Conexión wifi desactivada");
                }
                this.sleep(3000);
            } catch (InterruptedException e) {
                enEjecucion=false;
                Log.i(tag, "hilo del servicio interrumpido....");
            }
        }
    }

}
