package com.example.ej4practicar_comunicaciones_raulsanz;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.util.Log;

import androidx.annotation.Nullable;

public class WirelessTester extends Service {
    final String tag = "Demo Servicio";
    public boolean enEjecucion = false;
    public boolean wifi_activo = false;
    private Tester tester;


    @Override
    public void onCreate() {
        Log.i(tag, "Servicio WirelessTester creado!");
        tester = new Tester();
    }


    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (!enEjecucion) {
            enEjecucion = true;

            tester.start();
            Log.i(tag, "Servicio WirelessTester arrancado!");
        } else {
            Log.i(tag, "El servicio WirelessTester ya estaba arrancado!");
        }
        return START_STICKY;
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onDestroy() {
        Log.i(tag, "Servicio WirelessTester destruido!");
        if(enEjecucion)

            tester.interrupt();
    }
}
