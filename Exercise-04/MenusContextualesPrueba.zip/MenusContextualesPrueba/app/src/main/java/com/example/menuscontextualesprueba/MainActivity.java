package com.example.menuscontextualesprueba.;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements ListView.OnItemClickListener {

    private TextView textView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        String[] elementos = {"León", "Zamora", "Salamanca", "Palencia", "Valladolid"};
        AdaptadorPersonalizado adaptador;

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ListView l = findViewById(R.id.listview);
        adaptador = new AdaptadorPersonalizado(this, R.layout.fila, elementos);
        l.setAdapter(adaptador);
        l.setOnItemClickListener(this);

        textView = findViewById(R.id.textView);
    }

    @Override
    public void onItemClick(AdapterView<?> a, View view, int position, long id) {
        textView.setText("Has elegido:" + a.getItemAtPosition(position).toString());
    }
}
